class TabData{
  final String title;
  final String category_id;
  final String Sub_ctaegoty_id;
  const TabData(
  this.title,
  this.category_id,
  this.Sub_ctaegoty_id,
  );
}
