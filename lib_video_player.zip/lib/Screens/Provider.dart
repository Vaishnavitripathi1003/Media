import 'package:flutter/material.dart';

class VideoProvider extends ChangeNotifier {
  late String _currentVideoId;

  VideoProvider(String initialVideoId) {
    _currentVideoId = initialVideoId;
  }

  String get currentVideoId => _currentVideoId;

  void setCurrentVideoId(String videoId) {
    _currentVideoId = videoId;
    notifyListeners();
  }
}